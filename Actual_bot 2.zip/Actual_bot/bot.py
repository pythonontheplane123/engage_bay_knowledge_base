import discord
import random
import requests
from bs4 import BeautifulSoup
from discord.ext import commands
import schedule
import time

def blocking_function():
    time.sleep(5)
    print('iterations')
    return


#scraping quizlet
def quizlet_scraper(url):
  dict_scraped = {}
  headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:80.0) Gecko/20100101 Firefox/80.0'}
  soup = BeautifulSoup(requests.get(url, headers=headers).content, 'html.parser')
  for i, (question, answer) in enumerate(zip(soup.select('a.SetPageTerm-wordText'), soup.select('a.SetPageTerm-definitionText')), 1):
      dict_scraped[str(question.get_text(strip=True, separator='\n'))] = str(answer.get_text(strip=True, separator='\n'))
  return dict_scraped



quizlet_list_created=False
index = 0
res_1 = []
res_2 = []
flow = False
TOKEN= 'MTA0NzE2MTA0OTg2ODE1MjkzMw.GjKcVN.BnYLk2_kRCce4KY2nbs_uhfpH6A8ufHD0UHEgo'

def run_discord_bot():
    intents = discord.Intents.default()
    intents.message_content = True
    client = discord.Client(intents=intents)


    @client.event
    async def on_ready():
        print(f'{client.user} is now running!')


    @client.event
    async def on_message(message):
        # Make sure bot doesn't get stuck in an infinite loop
        global quizlet_list_created
        global index
        global res_1
        global res_2
        global flow


        if message.author == client.user:
            return

        # Get data about the user
        username = str(message.author)
        user_message = str(message.content)
        channel = str(message.channel)

        # Debug printing
        print(f"{username} said: '{user_message}' ({channel})")
        #instructions

        if user_message.lower() == 'quizlet':
            await message.channel.send("sounds good! send me a link to the flashcards and ill help you revise for them")

        #acc quizlet scraping

        if 'quizlet' in user_message:
            dict_with_words = quizlet_scraper(user_message)
            res_1 = list(dict_with_words.keys())
            res_2 = list(dict_with_words.values())
            quizlet_list_created = True
            print(str(res_1[0:5]))
            print(quizlet_list_created)
            await message.channel.send('list has been created. Type "start" to start revising')


        if user_message.lower() == 'start' and quizlet_list_created == True:
            await message.channel.send('practice has started')
            flow = True

        if flow and user_message.lower() == 'start':
            await message.channel.send('question ' + str(index+1) + ":" + str(res_1[index]))

            return

        if flow and user_message.lower() == 'end':
            quizlet_list_created = False
            await message.channel.send('okay, all data has been cleared')
            flow = False
            index = 0
            return

        if flow and user_message.lower != 'start':
            if flow and str(res_2[index]) == user_message:
                await message.add_reaction('✅')
                await message.add_reaction('😫')
                await message.channel.send('correct answer!')
                #for yede in range(int(10)):
                #    blocking_function()
                #    blocking_function()
                index += 1
                await message.channel.send('question ' + str(index + 1) + ":" + str(res_1[index]))
                return

            if flow and str(res_2[index]) != user_message:
                await message.add_reaction('💩')
                await message.channel.send('the answer is: ' + str(res_2[index]))
                #for yede in range(int(20/5)):
                #   blocking_function()
                #   blocking_function()
                index += 1
                await message.channel.send('question ' + str(index + 1) + ": " + str(res_1[index]))
                return

            if index == len(res_2):
                await message.channel.send('one cycle done')
                index = 0
                return



        #the return statement is a godly thing and also remove loop and just use rerturn statements.





            #make an on message function nested inside this. Loop is probably not neee
                # d , put it under the start function, basically check for the message thing while index < length of res_2 or 1 idk
                # i dont think that is possible

        # for changing something midflashcard, change the block functino to check if theres any input from the user,
        # if there is then act upon it during the waiting loop





        if user_message.lower() == 'start' and quizlet_list_created == False:
            await message.channel.send('send in a link before you say this')


        #HELP TAB
        if user_message.lower() == "help":
            await message.channel.send('')

    
    


        #add functionality to make quizlet_list_created == false once the idx reaches maximum limit ie all the flashcards have been exhausted.




        # If the user message contains a '?' in front of the text, it becomes a private message




    # Remember to run your bot with your personal TOKEN
    client.run(TOKEN)


